import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { SwiperModule } from 'swiper/angular';
import SwiperCore, { Autoplay, Keyboard, Pagination, Scrollbar, Zoom } from 'swiper';
import { IonicSlides } from '@ionic/angular';
import { Router } from '@angular/router';
import { UserService } from '../api/user.service';
import { IonModal } from '@ionic/angular';
import { OverlayEventDetail } from '@ionic/core/components';
import { ApiService } from '../services/api.service';
import { ExtraService } from '../services/extra.service';

SwiperCore.use([Autoplay, Keyboard, Pagination, Scrollbar, Zoom, IonicSlides]);
@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, SwiperModule]
})
export class HomePage implements OnInit {
  @ViewChild(IonModal) modal!: IonModal;
  choice1 = false;
  choice2 = true;
  choice3 = false;
  categories: any;

  ans = [{ ans1: 'chinese' }, { ans1: 'Itlian' }, { ans1: 'tokoyo' }]
  surveylists: any;
  answers: any;
  questionlist: any;
  selectedOption: any;
  isdown = false;
  selectedValue: any = '';
  currentIndex: any = 0;
  questionname: any;
  questionslength = 0;
  constructor(public router: Router,
    public user: UserService,
    public api: ApiService,
    public extra: ExtraService) { }

  ngOnInit() {

  }

  ionViewWillEnter() {
    this.user.loginVal = true;
    this.getCategories()
    this.getsurveylists()
  }

  getCategories() {
    this.api.getRequest('survey_categories').subscribe((res: any) => {
      console.log('categoreis=====', res);
      this.categories = res.data
    })
  }
  getsurveylists() {
    this.api.getRequest('survey_list_top').subscribe((res: any) => {
      console.log('survey_list_top=====', res);
      this.surveylists = res.data
    })
  }
  selectsurvey(val: any, index: any) {


    this.currentIndex = index



    console.log(val);

    this.api.sendRequest('survey_list_questions', { "survey_list_id": val.survey_list_id }).subscribe((res: any) => {
      console.log('survey_list_questions=====', res);
      this.questionlist = res.data[this.currentIndex];



      // this.questionslength = this.questionlist.length
      // this.answers = this.questionlist[this.currentIndex].answers

      // console.log(this.answers);
      // this.questionname = this.answers.name
      // this.questionlist[index].isdown = !(this.questionlist[index].isdown);
      // res.data.forEach((ele: any) => {
      //   // console.log(ele.answers);
      //   // let vales = ele.answers
      //   // vales.forEach((resval: any) => {
      //   //   resval.value = false;

      //   // });


      // });

    })
  }
  mcqAnswer(ev: any) {
    console.log(ev);
    this.selectedValue = ev.detail.value
    this.currentIndex++




  }
  getanswersvalues(val: any, index: any) {
    console.log('item obj====', val);


  }


  cancel() {
    this.modal.dismiss(null, 'cancel');
  }

  // confirm() {
  //   this.modal.dismiss(this.name, 'confirm');
  // }

  onWillDismiss(event: Event) {
    // const ev = event as CustomEvent<OverlayEventDetail<string>>;
    // if (ev.detail.role === 'confirm') {
    //   this.message = `Hello, ${ev.detail.data}!`;
    // }
  }



  sendText() {

  }


  handleChange(event: any) {


  }

  clearResult() {
    // this.result = []
    // this.showContent = true;
  }

  homeTab() {
    this.router.navigate(['/home']);
  }

  exploreTab() {
    this.router.navigate(['/explore']);
  }

  supportTab() {
    this.router.navigate(['/blog']);
  }

  profileTab() {
    this.router.navigate(['/profile']);
  }

}
